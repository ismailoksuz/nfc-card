# Dijital Kartvizit (Android)

Bilgilerini girersin (ad, ünvan, kurum, birim, telefon, e-posta, web sitesi, fotoğraf);
uygulama senin için aynı tasarımda kartı ve rehbere kaydeden vCard QR'ını üretir.
İnternet izni yoktur, bilgiler yalnızca telefonda saklanır.

## APK'yı almanın en kolay yolu (Android Studio gerekmez)
1. GitHub'da yeni bir depo aç (ör. `Kartvizit-App`) ve bu klasörün içindekileri yükle.
2. Depoda **Actions** sekmesine gir; "APK derle" kendiliğinden çalışır (ya da **Run workflow**).
3. İş bitince (yaklaşık 3-5 dk) çalışmanın sayfasında **Artifacts → kartvizit-apk** indir, zip'ten `app-debug.apk` çıkar.
4. APK'yı telefona at, aç; "bilinmeyen kaynaklardan yüklemeye izin ver" sorarsa izin ver.

## Android Studio ile
Klasörü **Open** ile aç, Gradle eşitlenince **Build → Build APK(s)**.
Çıktı: `app/build/outputs/apk/debug/app-debug.apk`

## NFC ile paylaşım (Android)
NFC'li telefonlarda QR sayfasında bir ipucu görünür. İki telefonu arka arkaya yaklaştırınca
karşı telefon kartı (vCard) okur ve rehbere ekleme ekranını açar. Telefon ekranı açık olmalı.
Telefonda NFC yoksa ya da kapalıysa ipucu buna göre değişir/görünmez.

## Yapı
- `app/src/main/assets/www/` : kartın kendisi (HTML/CSS/JS, yazı tipi ve ikonlar dahil, internetsiz çalışır)
  - `qr.js` QR üretici, `app.js` bilgi giriş ekranı + kart + vCard
- `app/src/main/java/.../MainActivity.kt` : WebView kabuğu, fotoğraf seçici, geri tuşu
  ve **Rehbere Kaydet** (telefonun rehber ekranını doğrudan açar)
- Kişi QR'ına web sitesi eklenmez (QR sade kalsın); "Rehbere Kaydet" düğmesi ise web sitesini de ekler.

Lisanslar: Manrope (SIL OFL 1.1, `assets/fonts/OFL.txt`), Font Awesome Free ikonlar (CC BY 4.0).
