/* ================= Veri ================= */
const STORE_KEY = 'kartvizit.v1';

function loadData() {
    try {
        const d = JSON.parse(localStorage.getItem(STORE_KEY) || 'null');
        return d && d.name ? d : null;
    } catch (e) { return null; }
}
function saveData(d) {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(d)); return true; } catch (e) { return false; }
}

const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
const trUpper = (s) => String(s || '').toLocaleUpperCase('tr-TR');

/* Telefonu rehbere uygun biçime getirir (Türkiye numaraları için +90 ekler) */
function normPhone(p) {
    let s = String(p || '').replace(/[^\d+]/g, '');
    if (!s) return '';
    if (s.startsWith('+')) return s;
    if (s.startsWith('00')) return '+' + s.slice(2);
    if (/^0\d{10}$/.test(s)) return '+9' + s;      // 05xx... -> +905xx...
    if (/^5\d{9}$/.test(s)) return '+90' + s;      // 5xx...  -> +905xx...
    return s;
}
function normUrl(u) {
    const s = String(u || '').trim();
    if (!s) return '';
    return /^[a-z][a-z0-9+.-]*:\/\//i.test(s) ? s : 'https://' + s;
}
function shortUrl(u) {
    return String(u || '').trim().replace(/^[a-z][a-z0-9+.-]*:\/\//i, '').replace(/\/$/, '');
}

/* QR'a girecek vCard 3.0 (web sitesi, QR sade kalsın diye eklenmez) */
function buildVCard(d, withWeb) {
    const esc = (s) => String(s).replace(/\\/g, '\\\\').replace(/\r?\n/g, '\\n').replace(/,/g, '\\,').replace(/;/g, '\\;');
    const full = d.name.trim().replace(/\s+/g, ' ');
    const parts = full.split(' ');
    const family = parts.length > 1 ? parts.pop() : '';
    const given = parts.join(' ');
    const lines = ['BEGIN:VCARD', 'VERSION:3.0', 'N:' + esc(family) + ';' + esc(given) + ';;;', 'FN:' + esc(full)];
    const org = [d.org, d.dept].map((x) => (x || '').trim()).filter(Boolean);
    if (org.length) lines.push('ORG:' + org.map(esc).join(';'));
    if ((d.title || '').trim()) lines.push('TITLE:' + esc(d.title.trim()));
    if (normPhone(d.phone)) lines.push('TEL;TYPE=CELL:' + normPhone(d.phone));
    if ((d.email || '').trim()) lines.push('EMAIL;TYPE=INTERNET:' + esc(d.email.trim()));
    if (withWeb && (d.web || '').trim()) lines.push('URL:' + normUrl(d.web));
    lines.push('END:VCARD');
    return lines.join('\r\n');
}

/* Fotoğraf yokken baş harfli bir görsel */
function avatarFor(name) {
    const words = String(name || '').trim().split(/\s+/).filter(Boolean);
    const ini = trUpper((words[0] ? words[0][0] : '') + (words.length > 1 ? words[words.length - 1][0] : ''));
    const inner = ini
        ? '<text x="100" y="100" dy=".35em" text-anchor="middle" font-family="Manrope,Arial,sans-serif" font-size="78" font-weight="600" fill="#b18a5a">' + ini.replace(/[<>&]/g, '') + '</text>'
        : '<circle cx="100" cy="78" r="34" fill="#b18a5a"/><path d="M36 178c0-34 28-56 64-56s64 22 64 56z" fill="#b18a5a"/>';
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><rect width="200" height="200" fill="#1c2a36"/>' + inner + '</svg>';
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
}

let current = null;

function render(d) {
    current = d;
    const photo = d.photo || avatarFor(d.name);
    $$('[data-photo]').forEach((img) => { img.src = photo; img.alt = d.name; });
    $$('[data-f="name"]').forEach((el) => { el.textContent = d.name; });
    $$('[data-f="title"]').forEach((el) => { el.textContent = trUpper(d.title); });
    $$('[data-institution]').forEach((el) => {
        el.textContent = '';
        [d.org, d.dept].map((x) => (x || '').trim()).filter(Boolean).forEach((line, i) => {
            if (i) el.appendChild(document.createElement('br'));
            el.appendChild(document.createTextNode(line));
        });
        el.parentNode.hidden = !el.firstChild;
    });

    const phone = (d.phone || '').trim(), email = (d.email || '').trim(), web = (d.web || '').trim();
    const rows = [
        [$('#c-phone'), phone, 'tel:' + normPhone(phone), phone],
        [$('#c-mail'), email, 'mailto:' + email, email],
        [$('#c-web'), web, normUrl(web), shortUrl(web)]
    ];
    let last = null;
    rows.forEach(([el, has, href, text]) => {
        el.hidden = !has;
        el.removeAttribute('data-last');
        if (!has) return;
        el.href = href;
        $('.contact-value', el).textContent = text;
        last = el;
    });
    if (last) last.setAttribute('data-last', '');

    try {
        $('#qr-card').innerHTML = QR.toSvg(QR.encode(buildVCard(d)), 4);
    } catch (e) {
        $('#qr-card').textContent = 'QR üretilemedi';
    }
    document.title = d.name;
    syncNfc(d);
}

/* NFC: Android uygulamasında telefon, etiket gibi davranıp kartı yaklaştırılan telefona verir */
const nfcHint = $('#nfc-hint');
function nfcBridge() {
    return window.Android && typeof window.Android.nfcStatus === 'function' ? window.Android : null;
}
function refreshNfcHint() {
    const a = nfcBridge();
    let state = 'none';
    try { if (a) state = a.nfcStatus(); } catch (e) {}
    if (state === 'none') { nfcHint.hidden = true; return; }
    nfcHint.hidden = false;
    nfcHint.dataset.state = state;
    nfcHint.textContent = state === 'on'
        ? 'NFC: telefonları arka arkaya yaklaştır'
        : 'NFC kapalı. Açmak için dokun';
}
function syncNfc(d) {
    const a = nfcBridge();
    if (!a) return;
    try { a.setCard(buildVCard(d, true)); } catch (e) {}
    refreshNfcHint();
}
nfcHint.addEventListener('click', () => {
    const a = nfcBridge();
    if (a && nfcHint.dataset.state === 'off') a.openNfcSettings();
});
// Ayarlardan dönünce durum yenilensin
document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshNfcHint(); });
window.addEventListener('focus', refreshNfcHint);

/* Rehbere kaydet: Android uygulamasında doğrudan rehber ekranı, tarayıcıda .vcf indirme */
$('#save-contact').addEventListener('click', () => {
    if (!current) return;
    const payload = {
        name: current.name.trim(), title: (current.title || '').trim(), org: (current.org || '').trim(),
        dept: (current.dept || '').trim(), phone: normPhone(current.phone), email: (current.email || '').trim(),
        web: normUrl(current.web)
    };
    if (window.Android && window.Android.saveContact) {
        window.Android.saveContact(JSON.stringify(payload));
        return;
    }
    const blob = new Blob([buildVCard(current)], { type: 'text/vcard' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = (current.name.trim().replace(/\s+/g, '-').toLowerCase() || 'kisi') + '.vcf';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
});

/* ================= Bilgi giriş ekranı ================= */
const setup = $('#setup');
const form = $('#setup-form');
const photoPreview = $('#photo-preview');
const photoFile = $('#photo-file');
const FIELDS = ['name', 'title', 'org', 'dept', 'phone', 'email', 'web'];
let pendingPhoto = '';

function refreshPhotoPreview() {
    photoPreview.src = pendingPhoto || avatarFor(form.elements.name.value);
    $('#photo-remove').hidden = !pendingPhoto;
}

function openSetup() {
    const d = current || {};
    FIELDS.forEach((f) => { form.elements[f].value = d[f] || ''; form.elements[f].classList.remove('is-invalid'); });
    pendingPhoto = d.photo || '';
    $('#setup-error').hidden = true;
    $('#setup-title').textContent = current ? 'Bilgilerini düzenle' : 'Kartını oluştur';
    $('#setup-cancel').hidden = !current;
    refreshPhotoPreview();
    $('.setup-scroll', setup).scrollTop = 0;
    setup.hidden = false;
    pager.inert = true;
}

function closeSetup() {
    setup.hidden = true;
    pager.inert = false;
}

form.elements.name.addEventListener('input', () => {
    if (!pendingPhoto) refreshPhotoPreview();
    form.elements.name.classList.remove('is-invalid');
    $('#setup-error').hidden = true;
});
form.addEventListener('submit', (e) => e.preventDefault());

$('#photo-btn').addEventListener('click', () => photoFile.click());
$('#photo-remove').addEventListener('click', () => { pendingPhoto = ''; refreshPhotoPreview(); });

// Seçilen fotoğrafı 512x512'ye kırpıp küçültür (telefonda az yer kaplasın)
photoFile.addEventListener('change', () => {
    const file = photoFile.files && photoFile.files[0];
    photoFile.value = '';
    if (!file) return;
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
        const side = Math.min(img.naturalWidth, img.naturalHeight);
        const canvas = document.createElement('canvas');
        canvas.width = canvas.height = 512;
        canvas.getContext('2d').drawImage(img,
            (img.naturalWidth - side) / 2, (img.naturalHeight - side) / 2, side, side, 0, 0, 512, 512);
        pendingPhoto = canvas.toDataURL('image/jpeg', 0.86);
        URL.revokeObjectURL(url);
        refreshPhotoPreview();
    };
    img.onerror = () => URL.revokeObjectURL(url);
    img.src = url;
});

$('#setup-save').addEventListener('click', () => {
    const name = form.elements.name.value.trim();
    if (!name) {
        form.elements.name.classList.add('is-invalid');
        $('#setup-error').hidden = false;
        form.elements.name.focus();
        return;
    }
    const d = { photo: pendingPhoto };
    FIELDS.forEach((f) => { d[f] = form.elements[f].value.trim(); });
    if (!saveData(d)) {
        // Saklama dolu/kapalıysa fotoğrafsız tekrar dene
        d.photo = '';
        saveData(d);
    }
    render(d);
    closeSetup();
    revealCard();
    changePage(0, true);
    pages.forEach(checkPage);
});
$('#setup-cancel').addEventListener('click', closeSetup);
$('#edit-btn').addEventListener('click', openSetup);

/* Android geri tuşu: önce açık ekranı kapat, sonra QR sayfasından dön */
window.__back = function () {
    if (!setup.hidden) {
        if (!current) return false;
        closeSetup();
        return true;
    }
    if (currentPage === 1) { changePage(0); return true; }
    return false;
};

function revealCard() {
    document.body.classList.remove('booting');
}

/* ---------- Sayfalar arası geçiş: İletişim <-> QR ---------- */
const pager = document.getElementById('pager');
const pages = Array.from(pager.querySelectorAll('.page'));
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
let currentPage = 0;
let animating = false;
let animFrame = null;

/* --- İçerik hazır mı? (yazı tipleri, ikon fontu, görseller) --- */
const FONT_CHECKS = [
    ['500 16px Manrope', 'İşğÖÜ abc']
];

const LOAD_TIMEOUT = 8000; // hiçbir şey sonsuza dek halkada kalmasın

function fontsReady() {
    try {
        return FONT_CHECKS.every(([spec, text]) => document.fonts.check(spec, text));
    } catch (e) {
        return true;
    }
}

function imagesReady(page) {
    return Array.from(page.querySelectorAll('img')).every((img) => img.complete);
}

function whenReady(page) {
    const imgs = Array.from(page.querySelectorAll('img'))
        .filter((img) => !img.complete)
        .map((img) => new Promise((resolve) => {
            img.addEventListener('load', resolve, { once: true });
            img.addEventListener('error', resolve, { once: true });
        }));
    const fonts = FONT_CHECKS.map(([spec, text]) => document.fonts.load(spec, text).catch(() => {}));
    const timeout = new Promise((resolve) => setTimeout(resolve, LOAD_TIMEOUT));
    return Promise.race([Promise.all([...fonts, ...imgs]), timeout]);
}

function checkPage(page) {
    if (fontsReady() && imagesReady(page)) {
        page.classList.remove('is-loading');
        return;
    }
    if (page.classList.contains('is-loading')) return;
    page.classList.add('is-loading');
    whenReady(page).then(() => {
        page.classList.remove('is-loading');
        page.classList.add('is-revealing');
        setTimeout(() => page.classList.remove('is-revealing'), 350);
    });
}

function setActivePage(index) {
    currentPage = index;
    // Görünmeyen sayfadaki bağlantılara Tab / ekran okuyucu ulaşmasın
    pages.forEach((page, i) => { page.inert = i !== index; });
    checkPage(pages[index]);
}

/* --- Masaüstü değiştirir gibi kayma: hızlı başlar, yumuşak yavaşlar --- */
function cubicBezier(x1, y1, x2, y2) {
    const cx = 3 * x1, bx = 3 * (x2 - x1) - cx, ax = 1 - cx - bx;
    const cy = 3 * y1, by = 3 * (y2 - y1) - cy, ay = 1 - cy - by;
    const sampleX = (t) => ((ax * t + bx) * t + cx) * t;
    const sampleY = (t) => ((ay * t + by) * t + cy) * t;
    const slopeX = (t) => (3 * ax * t + 2 * bx) * t + cx;
    return (x) => {
        let t = x;
        for (let i = 0; i < 8; i++) {
            const err = sampleX(t) - x;
            if (Math.abs(err) < 1e-5) break;
            const d = slopeX(t);
            if (Math.abs(d) < 1e-6) break;
            t -= err / d;
        }
        return sampleY(Math.min(1, Math.max(0, t)));
    };
}

// yumuşak başlar, uzun ve nazik yavaşlar (masaüstü geçişi hissi)
const slideEase = cubicBezier(0.4, 0, 0.1, 1);

function stopSlide() {
    cancelAnimationFrame(animFrame);
    if (animating) {
        animating = false;
        pager.style.scrollSnapType = '';
    }
}

function goToPage(index, instant) {
    stopSlide();
    const target = index * pager.clientWidth;
    const start = pager.scrollLeft;
    if (instant || reduceMotion.matches || Math.abs(target - start) < 1) {
        pager.scrollLeft = target;
        return;
    }
    const distance = target - start;
    const duration = 650;
    const t0 = performance.now();
    animating = true;
    pager.style.scrollSnapType = 'none';
    const step = (now) => {
        const t = Math.min(1, (now - t0) / duration);
        pager.scrollLeft = start + distance * slideEase(t);
        if (t < 1) {
            animFrame = requestAnimationFrame(step);
        } else {
            pager.scrollLeft = target;
            animating = false;
            pager.style.scrollSnapType = '';
        }
    };
    animFrame = requestAnimationFrame(step);
}

function changePage(index, instant) {
    if (index === currentPage && !animating) { if (instant) goToPage(index, true); return; }
    setActivePage(index);
    goToPage(index, instant);
}

document.querySelectorAll('[data-go]').forEach((btn) => {
    btn.addEventListener('click', () => changePage(Number(btn.dataset.go)));
});

// Parmak ya da tekerlek devreye girerse kayma animasyonu hemen bırakılır
['touchstart', 'pointerdown', 'wheel'].forEach((type) => {
    pager.addEventListener(type, stopSlide, { passive: true });
});

// Parmakla kaydırmada: yarıyı geçince aktif sayfa değişir
pager.addEventListener('scroll', () => {
    if (animating) return;
    const index = Math.round(pager.scrollLeft / pager.clientWidth);
    if (index === currentPage) return;
    setActivePage(index);
}, { passive: true });

window.addEventListener('resize', () => {
    if (!animating) goToPage(currentPage, true);
});


/* ================= Açılış ================= */
const LOADER_MIN = 1200;
const LOADER_MAX = 2500;
const loader = document.getElementById('loader');

function runLoader() {
    const photo = loader.querySelector('img');
    const photoReady = new Promise((resolve) => {
        if (photo.complete) return resolve();
        photo.addEventListener('load', resolve, { once: true });
        photo.addEventListener('error', resolve, { once: true });
    });
    const cap = new Promise((resolve) => setTimeout(resolve, LOADER_MAX));
    Promise.race([photoReady, cap]).then(() => {
        const wait = Math.max(0, LOADER_MIN - performance.now());
        setTimeout(() => loader.classList.add('hidden'), wait);
    });
}

const saved = loadData();
setActivePage(0);
if (saved) {
    render(saved);
    revealCard();
    runLoader();
} else {
    loader.classList.add('hidden');
    openSetup();
    revealCard();
}
pages.forEach(checkPage);
window.addEventListener('load', () => pages.forEach(checkPage));
