/* Küçük QR kod üreteci (Model 2, bayt modu / UTF-8, hata düzeltme: L).
   Dışarıdan hiçbir şeye ihtiyaç duymaz, internetsiz çalışır. */
(function (global) {
    'use strict';

    // Sürüm 1..40 için blok başına düzeltme kodu sayısı ve blok sayısı (seviye L)
    const ECC_PER_BLOCK = [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30];
    const NUM_BLOCKS = [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25];

    const bit = (x, i) => ((x >>> i) & 1) !== 0;

    function rawModules(ver) {
        let r = (16 * ver + 128) * ver + 64;
        if (ver >= 2) {
            const n = Math.floor(ver / 7) + 2;
            r -= (25 * n - 10) * n - 55;
            if (ver >= 7) r -= 36;
        }
        return r;
    }

    function dataCodewords(ver) {
        return Math.floor(rawModules(ver) / 8) - ECC_PER_BLOCK[ver] * NUM_BLOCKS[ver];
    }

    /* --- Reed-Solomon --- */
    function rsMul(x, y) {
        let z = 0;
        for (let i = 7; i >= 0; i--) {
            z = (z << 1) ^ ((z >>> 7) * 0x11D);
            z ^= ((y >>> i) & 1) * x;
        }
        return z;
    }
    function rsDivisor(degree) {
        const result = [];
        for (let i = 0; i < degree - 1; i++) result.push(0);
        result.push(1);
        let root = 1;
        for (let i = 0; i < degree; i++) {
            for (let j = 0; j < result.length; j++) {
                result[j] = rsMul(result[j], root);
                if (j + 1 < result.length) result[j] ^= result[j + 1];
            }
            root = rsMul(root, 2);
        }
        return result;
    }
    function rsRemainder(data, divisor) {
        const result = divisor.map(() => 0);
        for (const b of data) {
            const factor = b ^ result.shift();
            result.push(0);
            divisor.forEach((coef, i) => { result[i] ^= rsMul(coef, factor); });
        }
        return result;
    }

    function addEccAndInterleave(data, ver) {
        const numBlocks = NUM_BLOCKS[ver];
        const eccLen = ECC_PER_BLOCK[ver];
        const raw = Math.floor(rawModules(ver) / 8);
        const numShort = numBlocks - (raw % numBlocks);
        const shortLen = Math.floor(raw / numBlocks);
        const blocks = [];
        const div = rsDivisor(eccLen);
        for (let i = 0, k = 0; i < numBlocks; i++) {
            const dat = data.slice(k, k + shortLen - eccLen + (i < numShort ? 0 : 1));
            k += dat.length;
            const ecc = rsRemainder(dat, div);
            if (i < numShort) dat.push(0);
            blocks.push(dat.concat(ecc));
        }
        const result = [];
        for (let i = 0; i < blocks[0].length; i++) {
            blocks.forEach((block, j) => {
                if (i !== shortLen - eccLen || j >= numShort) result.push(block[i]);
            });
        }
        return result;
    }

    function utf8Bytes(text) {
        return Array.from(new TextEncoder().encode(text));
    }

    function buildData(bytes) {
        let ver = 1;
        for (; ; ver++) {
            if (ver > 40) throw new Error('Veri QR koda sığmıyor');
            const countBits = ver <= 9 ? 8 : 16;
            if (4 + countBits + bytes.length * 8 <= dataCodewords(ver) * 8) break;
        }
        const bits = [];
        const put = (val, len) => { for (let i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
        put(0x4, 4);
        put(bytes.length, ver <= 9 ? 8 : 16);
        bytes.forEach((b) => put(b, 8));
        const capBits = dataCodewords(ver) * 8;
        put(0, Math.min(4, capBits - bits.length));
        put(0, (8 - (bits.length % 8)) % 8);
        for (let pad = 0xEC; bits.length < capBits; pad ^= 0xEC ^ 0x11) put(pad, 8);
        const data = [];
        for (let i = 0; i < bits.length; i += 8) {
            let v = 0;
            for (let j = 0; j < 8; j++) v = (v << 1) | bits[i + j];
            data.push(v);
        }
        return { ver, data };
    }

    function alignPositions(ver, size) {
        if (ver === 1) return [];
        const n = Math.floor(ver / 7) + 2;
        const step = ver === 32 ? 26 : Math.ceil((ver * 4 + 4) / (n * 2 - 2)) * 2;
        const res = [6];
        for (let pos = size - 7; res.length < n; pos -= step) res.splice(1, 0, pos);
        return res;
    }

    function encode(text) {
        const { ver, data } = buildData(utf8Bytes(text));
        const size = ver * 4 + 17;
        const modules = Array.from({ length: size }, () => new Array(size).fill(false));
        const isFn = Array.from({ length: size }, () => new Array(size).fill(false));
        const setFn = (x, y, dark) => { modules[y][x] = dark; isFn[y][x] = true; };

        function drawFormat(mask) {
            const d = (1 << 3) | mask; // seviye L = 01
            let rem = d;
            for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
            const bits = ((d << 10) | rem) ^ 0x5412;
            for (let i = 0; i <= 5; i++) setFn(8, i, bit(bits, i));
            setFn(8, 7, bit(bits, 6));
            setFn(8, 8, bit(bits, 7));
            setFn(7, 8, bit(bits, 8));
            for (let i = 9; i < 15; i++) setFn(14 - i, 8, bit(bits, i));
            for (let i = 0; i < 8; i++) setFn(size - 1 - i, 8, bit(bits, i));
            for (let i = 8; i < 15; i++) setFn(8, size - 15 + i, bit(bits, i));
            setFn(8, size - 8, true);
        }

        function drawFinder(cx, cy) {
            for (let dy = -4; dy <= 4; dy++) {
                for (let dx = -4; dx <= 4; dx++) {
                    const dist = Math.max(Math.abs(dx), Math.abs(dy));
                    const x = cx + dx, y = cy + dy;
                    if (x >= 0 && x < size && y >= 0 && y < size) setFn(x, y, dist !== 2 && dist !== 4);
                }
            }
        }
        function drawAlign(cx, cy) {
            for (let dy = -2; dy <= 2; dy++) {
                for (let dx = -2; dx <= 2; dx++) setFn(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
            }
        }

        for (let i = 0; i < size; i++) {
            setFn(6, i, i % 2 === 0);
            setFn(i, 6, i % 2 === 0);
        }
        drawFinder(3, 3);
        drawFinder(size - 4, 3);
        drawFinder(3, size - 4);
        const pos = alignPositions(ver, size);
        const n = pos.length;
        for (let i = 0; i < n; i++) {
            for (let j = 0; j < n; j++) {
                if (!((i === 0 && j === 0) || (i === 0 && j === n - 1) || (i === n - 1 && j === 0))) drawAlign(pos[i], pos[j]);
            }
        }
        drawFormat(0);
        if (ver >= 7) {
            let rem = ver;
            for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
            const bits = (ver << 12) | rem;
            for (let i = 0; i < 18; i++) {
                const a = size - 11 + (i % 3), b = Math.floor(i / 3);
                setFn(a, b, bit(bits, i));
                setFn(b, a, bit(bits, i));
            }
        }

        // Veriyi yılan düzeninde yerleştir
        const all = addEccAndInterleave(data, ver);
        let bi = 0;
        for (let right = size - 1; right >= 1; right -= 2) {
            if (right === 6) right = 5;
            for (let vert = 0; vert < size; vert++) {
                for (let j = 0; j < 2; j++) {
                    const x = right - j;
                    const upward = ((right + 1) & 2) === 0;
                    const y = upward ? size - 1 - vert : vert;
                    if (!isFn[y][x] && bi < all.length * 8) {
                        modules[y][x] = bit(all[bi >>> 3], 7 - (bi & 7));
                        bi++;
                    }
                }
            }
        }

        function applyMask(mask) {
            for (let y = 0; y < size; y++) {
                for (let x = 0; x < size; x++) {
                    let inv;
                    switch (mask) {
                        case 0: inv = (x + y) % 2 === 0; break;
                        case 1: inv = y % 2 === 0; break;
                        case 2: inv = x % 3 === 0; break;
                        case 3: inv = (x + y) % 3 === 0; break;
                        case 4: inv = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; break;
                        case 5: inv = ((x * y) % 2) + ((x * y) % 3) === 0; break;
                        case 6: inv = ((((x * y) % 2) + ((x * y) % 3)) % 2) === 0; break;
                        default: inv = ((((x + y) % 2) + ((x * y) % 3)) % 2) === 0;
                    }
                    if (!isFn[y][x] && inv) modules[y][x] = !modules[y][x];
                }
            }
        }

        function penalty() {
            let p = 0;
            const line = (get) => {
                let run = 1;
                for (let i = 1; i < size; i++) {
                    if (get(i) === get(i - 1)) {
                        run++;
                        if (run === 5) p += 3; else if (run > 5) p += 1;
                    } else run = 1;
                }
                const s = [];
                for (let i = 0; i < size; i++) s.push(get(i) ? 1 : 0);
                const str = s.join('');
                const count = (pat) => { let c = 0, k = -1; while ((k = str.indexOf(pat, k + 1)) !== -1) c++; return c; };
                p += 40 * (count('10111010000') + count('00001011101'));
            };
            for (let y = 0; y < size; y++) line((x) => modules[y][x]);
            for (let x = 0; x < size; x++) line((y) => modules[y][x]);
            for (let y = 0; y < size - 1; y++) {
                for (let x = 0; x < size - 1; x++) {
                    const c = modules[y][x];
                    if (c === modules[y][x + 1] && c === modules[y + 1][x] && c === modules[y + 1][x + 1]) p += 3;
                }
            }
            let dark = 0;
            modules.forEach((row) => row.forEach((c) => { if (c) dark++; }));
            const total = size * size;
            p += (Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1) * 10;
            return p;
        }

        let best = 0, bestP = Infinity;
        for (let m = 0; m < 8; m++) {
            applyMask(m);
            drawFormat(m);
            const p = penalty();
            if (p < bestP) { bestP = p; best = m; }
            applyMask(m); // geri al
        }
        applyMask(best);
        drawFormat(best);
        return { size, version: ver, modules };
    }

    // Beyaz zeminli, 4 modül sessiz alanlı SVG metni
    function toSvg(qr, border) {
        const b = border === undefined ? 4 : border;
        const s = qr.size + b * 2;
        let d = '';
        for (let y = 0; y < qr.size; y++) {
            let x = 0;
            while (x < qr.size) {
                if (qr.modules[y][x]) {
                    let w = 1;
                    while (x + w < qr.size && qr.modules[y][x + w]) w++;
                    d += 'M' + (x + b) + ',' + (y + b) + 'h' + w + 'v1h-' + w + 'z';
                    x += w;
                } else x++;
            }
        }
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + s + ' ' + s + '" shape-rendering="crispEdges">' +
            '<rect width="' + s + '" height="' + s + '" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>';
    }

    global.QR = { encode, toSvg };
})(typeof window !== 'undefined' ? window : globalThis);
