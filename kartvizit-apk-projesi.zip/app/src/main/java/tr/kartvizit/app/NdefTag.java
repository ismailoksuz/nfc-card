package tr.kartvizit.app;

import java.nio.charset.StandardCharsets;

/**
 * NFC Forum Type 4 Tag taklidi (yalnızca okunur). Android API'sine bağımlı değil,
 * böylece mantık tek başına test edilebilir. Okuyucu telefon bu "etiketi" okuyunca
 * içindeki NDEF mesajını (vCard) alır.
 */
public final class NdefTag {

    public static final byte[] AID = {
            (byte) 0xD2, 0x76, 0x00, 0x00, (byte) 0x85, 0x01, 0x01};

    private static final byte[] OK = {(byte) 0x90, 0x00};
    private static final byte[] NOT_FOUND = {0x6A, (byte) 0x82};
    private static final byte[] BAD_OFFSET = {0x6B, 0x00};
    private static final byte[] UNSUPPORTED = {0x6D, 0x00};

    private static final int MAX_READ = 0xFF;

    // Yetenek dosyası (CC): 15 bayt, NDEF dosyası E104, okunur / yazılamaz
    private static final byte[] CC = {
            0x00, 0x0F, 0x20, 0x00, (byte) 0xFF, 0x00, (byte) 0xFF,
            0x04, 0x06, (byte) 0xE1, 0x04, 0x08, 0x00, 0x00, (byte) 0xFF};

    private final byte[] ndefFile; // 2 bayt uzunluk + NDEF mesajı
    private boolean appSelected = false;
    private int selected = 0; // 0 yok, 1 CC, 2 NDEF

    public NdefTag(byte[] ndefMessage) {
        ndefFile = new byte[2 + ndefMessage.length];
        ndefFile[0] = (byte) (ndefMessage.length >> 8);
        ndefFile[1] = (byte) ndefMessage.length;
        System.arraycopy(ndefMessage, 0, ndefFile, 2, ndefMessage.length);
    }

    /** Tek kayıtlı bir MIME NDEF mesajı üretir (ör. text/vcard). */
    public static byte[] buildMimeNdef(String mime, byte[] payload) {
        byte[] type = mime.getBytes(StandardCharsets.US_ASCII);
        boolean shortRecord = payload.length < 256;
        int flags = 0x80 | 0x40 | 0x02 | (shortRecord ? 0x10 : 0x00); // MB | ME | MIME
        int header = 2 + (shortRecord ? 1 : 4);
        byte[] out = new byte[header + type.length + payload.length];
        int i = 0;
        out[i++] = (byte) flags;
        out[i++] = (byte) type.length;
        if (shortRecord) {
            out[i++] = (byte) payload.length;
        } else {
            out[i++] = (byte) (payload.length >>> 24);
            out[i++] = (byte) (payload.length >>> 16);
            out[i++] = (byte) (payload.length >>> 8);
            out[i++] = (byte) payload.length;
        }
        System.arraycopy(type, 0, out, i, type.length);
        i += type.length;
        System.arraycopy(payload, 0, out, i, payload.length);
        return out;
    }

    /** Boş NDEF mesajı (kart henüz oluşturulmadıysa). */
    public static byte[] emptyMessage() {
        return new byte[]{(byte) 0xD0, 0x00, 0x00};
    }

    public byte[] process(byte[] c) {
        if (c == null || c.length < 4) return UNSUPPORTED;
        int ins = c[1] & 0xFF;
        int p1 = c[2] & 0xFF;
        int p2 = c[3] & 0xFF;

        if (ins == 0xA4) { // SELECT
            int lc = c.length > 4 ? (c[4] & 0xFF) : 0;
            if (p1 == 0x04) { // ada göre: NDEF uygulaması
                if (lc == AID.length && c.length >= 5 + lc && matchesAid(c)) {
                    appSelected = true;
                    selected = 0;
                    return OK;
                }
                appSelected = false;
                selected = 0;
                return NOT_FOUND;
            }
            if (p1 == 0x00 && appSelected && lc == 2 && c.length >= 7) { // dosya kimliğine göre
                int fid = ((c[5] & 0xFF) << 8) | (c[6] & 0xFF);
                if (fid == 0xE103) { selected = 1; return OK; }
                if (fid == 0xE104) { selected = 2; return OK; }
            }
            return NOT_FOUND;
        }

        if (ins == 0xB0) { // READ BINARY
            if (!appSelected || selected == 0) return NOT_FOUND;
            byte[] file = selected == 1 ? CC : ndefFile;
            int offset = ((p1 & 0x7F) << 8) | p2;
            int le = c.length > 4 ? (c[4] & 0xFF) : 256;
            if (le == 0) le = 256;
            if (offset > file.length) return BAD_OFFSET;
            int n = Math.min(Math.min(le, MAX_READ), file.length - offset);
            byte[] out = new byte[n + 2];
            System.arraycopy(file, offset, out, 0, n);
            out[n] = (byte) 0x90;
            out[n + 1] = 0x00;
            return out;
        }
        return UNSUPPORTED;
    }

    private static boolean matchesAid(byte[] c) {
        for (int i = 0; i < AID.length; i++) {
            if (c[5 + i] != AID[i]) return false;
        }
        return true;
    }
}
