package tr.kartvizit.app

import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.nfc.NfcAdapter
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.ContactsContract.CommonDataKinds.Organization
import android.provider.ContactsContract.CommonDataKinds.Website
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // Fotoğraf seçici (galeri / dosyalar)
    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            filePathCallback?.onReceiveValue(uris)
            filePathCallback = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.parseColor("#F4F1ED")
        window.navigationBarColor = Color.parseColor("#14212C")
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = false
        }

        // Sayfa dosyaları uygulamanın içinden, güvenli (https) bir adresmiş gibi sunulur;
        // böylece kayıtlı bilgiler (localStorage) kalıcı olur.
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        setContentView(webView)
        webView.setBackgroundColor(Color.parseColor("#F4F1ED"))

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            textZoom = 100
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            // tel:, mailto: ve web bağlantıları ilgili uygulamada açılır
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.host == "appassets.androidplatform.net") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (e: Exception) {
                    // açacak uygulama yok, yoksay
                }
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                return try {
                    fileChooser.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        webView.addJavascriptInterface(Bridge(), "Android")

        // Geri tuşu: önce sayfa içi (QR -> iletişim, form -> kart), olmazsa uygulamadan çık
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("window.__back ? window.__back() : false") { result ->
                    if (result != "true") finish()
                }
            }
        })

        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    /** Sayfadaki "Rehbere Kaydet" düğmesi buraya gelir: doğrudan rehberin kişi ekleme ekranı açılır. */
    inner class Bridge {

        /** NFC ile paylaşılacak kartı (vCard) saklar; CardService buradan okur. */
        @JavascriptInterface
        fun setCard(vcard: String) {
            getSharedPreferences("card", MODE_PRIVATE).edit().putString("vcard", vcard).apply()
        }

        /** "none": telefonda NFC yok, "off": kapalı, "on": açık */
        @JavascriptInterface
        fun nfcStatus(): String {
            val hasHce = packageManager.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION)
            val adapter = NfcAdapter.getDefaultAdapter(this@MainActivity)
            return when {
                !hasHce || adapter == null -> "none"
                adapter.isEnabled -> "on"
                else -> "off"
            }
        }

        @JavascriptInterface
        fun openNfcSettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_NFC_SETTINGS))
                } catch (e: Exception) {
                    // ayar ekranı açılamadı
                }
            }
        }

        @JavascriptInterface
        fun saveContact(json: String) {
            runOnUiThread {
                try {
                    val o = JSONObject(json)
                    val data = ArrayList<ContentValues>()

                    val org = o.optString("org")
                    val dept = o.optString("dept")
                    val title = o.optString("title")
                    if (org.isNotEmpty() || dept.isNotEmpty() || title.isNotEmpty()) {
                        data.add(ContentValues().apply {
                            put(ContactsContract.Data.MIMETYPE, Organization.CONTENT_ITEM_TYPE)
                            put(Organization.COMPANY, org)
                            put(Organization.DEPARTMENT, dept)
                            put(Organization.TITLE, title)
                        })
                    }
                    val web = o.optString("web")
                    if (web.isNotEmpty()) {
                        data.add(ContentValues().apply {
                            put(ContactsContract.Data.MIMETYPE, Website.CONTENT_ITEM_TYPE)
                            put(Website.URL, web)
                        })
                    }

                    val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
                        type = ContactsContract.RawContacts.CONTENT_TYPE
                        putExtra(ContactsContract.Intents.Insert.NAME, o.optString("name"))
                        putExtra(ContactsContract.Intents.Insert.PHONE, o.optString("phone"))
                        putExtra(
                            ContactsContract.Intents.Insert.PHONE_TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                        )
                        putExtra(ContactsContract.Intents.Insert.EMAIL, o.optString("email"))
                        putParcelableArrayListExtra(ContactsContract.Intents.Insert.DATA, data)
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    // rehber uygulaması yoksa sessizce geç
                }
            }
        }
    }
}
