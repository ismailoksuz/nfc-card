package tr.kartvizit.app

import android.nfc.cardemulation.HostApduService
import android.os.Bundle

/**
 * Telefonu NFC etiketi gibi gösterir: yaklaştırılan telefon kartı (vCard) okur
 * ve rehbere ekleme ekranını açar. Kart bilgisi uygulama içinde kaydedilir.
 */
class CardService : HostApduService() {

    private var tag: NdefTag? = null

    override fun processCommandApdu(commandApdu: ByteArray, extras: Bundle?): ByteArray {
        val current = tag ?: NdefTag(loadMessage()).also { tag = it }
        return current.process(commandApdu)
    }

    override fun onDeactivated(reason: Int) {
        tag = null
    }

    private fun loadMessage(): ByteArray {
        val vcard = getSharedPreferences("card", MODE_PRIVATE).getString("vcard", "") ?: ""
        return if (vcard.isEmpty()) {
            NdefTag.emptyMessage()
        } else {
            NdefTag.buildMimeNdef("text/vcard", vcard.toByteArray(Charsets.UTF_8))
        }
    }
}
